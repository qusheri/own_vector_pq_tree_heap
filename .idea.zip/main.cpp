#include "interface.h"
using namespace std;

int main() {
    interface();
}