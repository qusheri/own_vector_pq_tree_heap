#pragma once

#include <iostream>

template<typename T>
class Sequence {
public:
    virtual ~Sequence() = default;

    [[nodiscard]] virtual size_t Size() const = 0;

    virtual void Clear() = 0;

    virtual void PushBack(const T &value) = 0;

    virtual bool Erase(size_t pos) = 0;

    virtual void Insert(size_t pos, const T &value) = 0;

    virtual T &operator[](const size_t i) = 0;

    virtual const T &operator[](const size_t i) const = 0;

    virtual void PopBack() = 0;
};

template<typename T>
class ListSequence : public Sequence<T> {
private:
    struct Node {
        T value;
        Node *next;

        explicit Node(const T &value) : value(value), next(nullptr) {}
    };

    Node *head;
    size_t size_ = 0;
public:

    ListSequence() : head(nullptr), size_(0) {}

    ~ListSequence() {
        while (head) {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
        size_ = 0;
    }

    void PopBack() {
        if (!head) {
            return;
        }
        Node *current = head;
        while (current->next && current->next->next) {
            current = current->next;
        }
        delete current->next;
        current->next = nullptr;

        --size_;
    }

    void PushBack(const T &value) {
        if (!head) {
            head = new Node(value);
        } else {
            Node *current = head;
            while (current->next) {
                current = current->next;
            }
            current->next = new Node(value);
        }
        ++size_;
    }

    [[nodiscard]] size_t Size() const {
        return size_;
    }

    void Clear() {
        while (head) {
            Node *temp = head;
            head = head->next;
            delete temp;
        }
        size_ = 0;
    }

    void Insert(size_t pos, const T &value) {
        if (pos > size_) {
            throw std::out_of_range("Out of range");
        }
        if (pos == 0) {
            Node *newNode = new Node(value);
            newNode->next = head;
            head = newNode;
        } else {
            Node *current = head;
            for (size_t i = 0; i < pos - 1; ++i) {
                current = current->next;
            }
            Node *newNode = new Node(value);
            newNode->next = current->next;
            current->next = newNode;
        }
        ++size_;
    }

    bool Erase(size_t pos) {
        if (pos >= size_) {
            throw std::out_of_range("Out of range");
        }
        if (pos == 0) {
            Node *temp = head;
            head = head->next;
            delete temp;
        } else {
            Node *current = head;
            for (size_t i = 0; i < pos - 1; ++i) {
                current = current->next;
            }
            Node *temp = current->next;
            current->next = temp->next;
            delete temp;
        }
        --size_;
        return true;
    }


    bool operator==(const ListSequence &it) const {
        if (size_ != it.size_) return false;
        Node *current = head;
        Node *it_current = it.head;
        while (current) {
            if (current->value != it_current->value) return false;
            current = current->next;
            it_current = it_current->next;
        }
        return true;
    }

    bool operator!=(const ListSequence &it) const {
        return *this != it;
    }

    bool operator<(const ListSequence &it) const {
        size_t mini = std::min(it.size_, size_);
        for (size_t i = 0; i < mini; ++i) {
            if ((*this)[i] < it[i]) {
                return true;
            }
        }
        return false;
    }

    bool operator>(const ListSequence &it) const {
        return it < *this;
    }

    bool operator<=(const ListSequence &it) const {
        return *this <= it;
    }

    bool operator>=(const ListSequence &it) const {
        return *this >= it;
    }

    T &operator[](const size_t i) {
        Node *current = head;
        for (size_t j = 0; j < i; ++j) {
            current = current->next;
        }
        return current->value;
    }

    const T &operator[](const size_t i) const {
        Node *current = head;
        for (size_t j = 0; j < i; ++j) {
            current = current->next;
        }
        return current->value;
    }
};

template<typename T>
class Array_Sequence : public Sequence<T> {
private:
    size_t size_;
    size_t capacity_;
    T *val;
public:
    Array_Sequence() : size_(0), capacity_(2), val(new T[2]) {
    }

    Array_Sequence(const Array_Sequence &array) : size_(array.size_), capacity_(array.capacity_),
                                                  val(new T[capacity_]) {
        std::copy(array.val, array.val + size_, val);
    }

    Array_Sequence(size_t size, T defaultValue = 0) : size_(size), capacity_(size * 2), val(new T[capacity_]) {
        for (size_t i = 0; i < size; ++i) {
            val[i] = defaultValue;
        }
    }

    ~Array_Sequence() {
        delete[] val;
    }

    [[nodiscard]] size_t Size() const {
        return size_;
    }

    [[nodiscard]] size_t Capacity() const {
        return capacity_;
    }

    void Reserve(size_t newCapacity) {
        if (newCapacity <= capacity_) {
            return;
        }
        T *tmp = new T[newCapacity];
        std::copy(val, val + size_, tmp);
        delete[] val;
        val = tmp;
        capacity_ = newCapacity;
    }

    void Resize(size_t newSize) {
        if (newSize == size_) return;
        if (newSize > capacity_) Reserve(newSize * 2);
        if (newSize < size_) {
            for (size_t i = newSize; i < size_; ++i) {
                val[i].~T();
            }
        }
        size_ = newSize;
    }

    void PushBack(const T &value = 0) {
        if (size_ == capacity_) {
            Reserve(capacity_ * 2);
        }
        val[size_++] = value;
    }

    void PopBack() {
        if (size_ == 0) {
            throw std::out_of_range("Empty array");
        }
        val[--size_].~T();
    }

    const T &operator[](const size_t i) const {
        return val[i];
    }

    T &operator[](const size_t i) {
        return val[i];
    }

    explicit operator bool() const {
        return size_ > 0;
    }

    bool operator<(const Array_Sequence &it) const {
        size_t mini = std::min(it.size_, size_);
        for (size_t i = 0; i < mini; ++i) {
            if ((*this)[i] < it[i]) {
                return true;
            }
        }
        return false;
    }

    bool operator>(const Array_Sequence &it) const {
        return it < *this;
    }

    bool operator!=(const Array_Sequence &it) const {
        return *this != it;
    }

    bool operator==(const Array_Sequence &it) const {
        if (size_ != it.size_) return false;
        for (size_t i = 0; i < size_; ++i) {
            if ((*this)[i] != it[i]) return false;
        }
        return true;
    }

    bool operator<=(const Array_Sequence &it) const {
        return *this <= it;
    }

    bool operator>=(const Array_Sequence &it) const {
        return *this >= it;
    }


    void Insert(size_t pos, const T &value) {
        if (pos > size_) {
            throw std::out_of_range("Out of range");
        }
        if (size_ == capacity_) {
            Reserve(capacity_ * 2);
        }
        for (size_t i = size_; i > pos; --i) {
            val[i] = val[i - 1];
        }
        val[pos] = value;
        ++size_;
    }

    bool Erase(size_t pos) {
        if (pos >= size_) {
            throw std::out_of_range("Out of range");
        }
        for (size_t i = pos; i < size_ - 1; ++i) {
            val[i] = val[i + 1];
        }
        --size_;
        return true;
    }

    void Clear() {
        delete[] val;
        val = new T[capacity_];
        size_ = 0;
    }
};