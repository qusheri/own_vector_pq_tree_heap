template<typename T>
class DynamicArray {
public:
    DynamicArray() : array_() {}

    DynamicArray(const DynamicArray &other) : array_(other.array_) {}

    DynamicArray(size_t size, T defaultValue = 0) : array_(size, defaultValue) {}

    ~DynamicArray() = default;

    [[nodiscard]] size_t Size() const {
        return array_.Size();
    }

    void Resize(size_t newSize) {
        array_.Resize(newSize);
    }

    void PushBack(const T &value = 0) {
        array_.PushBack(value);
    }

    void PopBack() {
        array_.PopBack();
    }

    const T &operator[](const size_t i) const {
        return array_[i];
    }

    T &operator[](const size_t i) {
        return array_[i];
    }

    [[nodiscard]] bool Empty() const {
        return array_.Size() == 0;
    }

    void Clear() {
        array_.Clear();
    }

private:
    Array_Sequence <T> array_;
};