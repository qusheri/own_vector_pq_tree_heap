#pragma once

#include "definitions.h"

template<typename T>
class List {
private:
    ListSequence<T> list;
public:
    List() = default;

    List(const List<T> &other) {
        list = other.list;
    }

    ~List() = default;

    void PushBack(const T &value) {
        list.PushBack(value);
    }

    void PopBack() {
        list.PopBack();
    }

    T Get(size_t i) const {
        return list[i];
    }

    [[nodiscard]] size_t Size() const {
        return list.Size();
    }

    void Clear() {
        list.Clear();
    }

    T GetFirst() const {
        return list[0];
    }

    T GetLast() const {
        return list[list.Size() - 1];
    }

    List<T> *GetSubList(size_t start, size_t end) {
        return new List<T>(list.GetSubList(start, end));
    }

    [[nodiscard]] size_t GetLenght() const {
        return list.Size();
    }

    void PushFront(const T &value) {
        list.Insert(0, value);
    }

    void Insert(size_t pos, const T &value) {
        list.Insert(pos, value);
    }

    void Erase(size_t pos) {
        list.Erase(pos);
    }

    List<T> &operator=(const List<T> &other) {
        if (this != &other) {
            list = other.list;
        }
        return *this;
    }
};