#include <cassert>
#include "immutable_list.h"
#include "list.h"
#include "dynamic_array.h"

void TestSequence(Sequence<int> *sequence) {
    ImmutableLinkedList<int> list1;
    ImmutableLinkedList<int> newList = list1.Insert(0, 10);
    assert(newList.Size() == 1);
    assert(newList[0] == 10);
    newList = newList.Insert(1, 15);
    assert(newList.Size() == 3);
    assert(newList[1] == 15);
    assert(newList[2] == 20);

    std::cout << "IMMUTABLE LINKED LIST TEST #1 PASSED SUCCESSFULLY\n";


    newList = newList.Insert(1, 20);
    assert(newList.Size() == 2);
    assert(newList[1] == 20);

    ImmutableLinkedList<int> list2;
    ImmutableLinkedList<int> newList2 = list2.Insert(0, 10);
    newList = newList.Insert(1, 20);
    newList = newList.Insert(2, 30);

    newList = newList.Erase(0);

    assert(newList[0] == 20);
    assert(newList[1] == 30);

    newList = newList.Erase(0);

    assert(newList[0] == 30);

    std::cout << "IMMUTABLE LINKED LIST TEST #2 PASSED SUCCESSFULLY\n";

    List<int> list;
    list.PushBack(1);
    list.PushFront(2);
    assert(list.Get(0) == 2);
    assert(list.Get(1) == 1);

    list.PushBack(3);
    list.PushBack(4);
    assert(list.Get(0) == 2);
    assert(list.Get(1) == 1);
    assert(list.Get(2) == 3);
    assert(list.Get(3) == 4);
    assert(list.GetFirst() == 2);
    assert(list.GetLast() == 4);

    list.PushBack(5);
    list.PushBack(6);
    assert(list.Get(0) == 2);
    assert(list.Get(1) == 1);
    assert(list.Get(2) == 3);
    assert(list.Get(3) == 4);
    assert(list.Get(4) == 5);
    assert(list.Get(5) == 6);
    assert(list.GetFirst() == 2);
    assert(list.GetLast() == 6);

    std::cout << "LINKED LIST TEST PASSED SUCCESSFULLY\n";

    DynamicArray<int> dynArray;

    dynArray.PushBack(1);
    dynArray.PushBack(2);
    dynArray.PushBack(3);

    assert(dynArray.Size() == 3);
    assert(dynArray[0] == 1);
    assert(dynArray[1] == 2);
    assert(dynArray[2] == 3);

    dynArray.Clear();

    assert(dynArray.Size() == 0);
    assert(sequence->Size() == 0);

    sequence->PushBack(10);
    sequence->PushBack(20);

    assert((*sequence)[0] == 10);
    assert((*sequence)[1] == 20);

    std::cout << "DYNAMIC ARRAY TEST PASSED SUCCESSFULLY\n";

    Array_Sequence<int> array;
    ListSequence<int> linkedlist;
    Sequence<int> *sequence2;
    if (sequence == dynamic_cast<ListSequence<int> *>(sequence)) {
        sequence2 = static_cast<Sequence<int> *>(&array);
    } else {
        sequence2 = static_cast<Sequence<int> *>(&linkedlist);
    }
    sequence2->PushBack(10);
    sequence2->PushBack(20);

    sequence->Insert(1, 15);
    assert((*sequence)[1] == 15);

    sequence->Insert(0, 5);
    assert((*sequence)[0] == 5);
    assert((*sequence)[1] == 10);
    assert((*sequence)[2] == 15);
    assert((*sequence)[3] == 20);

    sequence->Insert(sequence->Size(), 25);
    assert((*sequence)[sequence->Size() - 1] == 25);

    assert(sequence->Erase(1));
    assert((*sequence)[1] == 15);

    assert(sequence->Erase(0));

    assert(sequence->Erase(sequence->Size() - 1));
    sequence->Clear();
    assert(sequence->Size() == 0);

    assert(sequence->Size() == 0);

    sequence->PushBack(10);
    sequence->PushBack(20);

    assert((*sequence)[0] == 10);
    assert((*sequence)[1] == 20);

    sequence->PopBack();
    assert(sequence->Size() == 1);
    assert((*sequence)[0] == 10);

    sequence->Clear();
    assert(sequence->Size() == 0);

    std::cout << "ALL TESTS PASSED SUCCESSFULLY\n";
}


